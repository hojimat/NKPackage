from setuptools import setup
#
setup(name='nkpack',
      version='1.0')
