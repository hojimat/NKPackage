## Helfpul utilities for NK-modeling

#### Infor about NK Models
Kauffman 1989

#### Info about the package

version 1.0


