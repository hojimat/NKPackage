"""NKPackage for agent-based modeling using NK-framework in Python"""

from .funcspace import *
